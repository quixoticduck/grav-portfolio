---
content:
    items: '@self.children'
---

Codebar