---
content:
    items: '@self.children'
---


between windows and mac