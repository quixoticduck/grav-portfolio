---
content:
    items: '@self.children'
---