#!/bin/sh
gosass -input scss/ -output css-compiled/ -sourcemap -watch -style compressed
