---
title: Dashboard Logout

form:
    fields:
        - name: username
          type: text
          placeholder: PLUGIN_ADMIN.USERNAME
          autofocus: true

        - name: password
          type: password
          placeholder: PLUGIN_ADMIN.PASSWORD
---
